# Master version for Pillow
__version__ = "7.2.0"
